package com.keremkulac.karakoctekstil.adapter

import com.keremkulac.karakoctekstil.model.Pattern

interface PatternClickListener {
    fun onPatternClicked(pattern: Pattern)
}