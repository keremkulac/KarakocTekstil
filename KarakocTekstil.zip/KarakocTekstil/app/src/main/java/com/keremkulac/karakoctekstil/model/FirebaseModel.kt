package com.keremkulac.karakoctekstil.model



data class FirebaseModel(
    var name : String?,
    var width : String?,
    var height : String?,
    var hit : String?,
    var pattern_url : String?)